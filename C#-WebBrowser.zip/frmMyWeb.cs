﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyWeb
{
    public partial class frmMyWeb : Form
    {
        public frmMyWeb()
        {
            InitializeComponent();
        }

        private void MyWeb_Load(object sender, EventArgs e)
        {
            wbMyWeb.GoHome();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            wbMyWeb.GoHome();
        }

        private void URLNavigate(string address)
        {
            if (string.IsNullOrEmpty(address))
                return;
            if (address == "about:blank")
                return;
            if (!address.StartsWith("http://") && !address.StartsWith("Https://"))
                    address = "http://" + address;
            try
            {
                wbMyWeb.Navigate(new Uri(address));
            }
            catch(UriFormatException e)
            {
                lblStatus.Text = e.Message;
            }
            catch(Exception e)
            {
                lblStatus.Text = e.Message;
            }
        }
        private void cboAddress_DropDown(object sender, EventArgs e)
        {

        }

        private void cboAddress_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                URLNavigate(cboAddress.Text);
            }
        }

        private void wbMyWeb_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            cboAddress.Items.Remove(wbMyWeb.Url.ToString());
            cboAddress.Items.Insert(0, wbMyWeb.Url.ToString());
            cboAddress.Text = wbMyWeb.Url.ToString();
        }

        private void wbMyWeb_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void cboAddress_Click(object sender, EventArgs e)
        {
            //cboAddress.SelectAll();
            //URLNavigate(cboAddress.Text);
        }

        private void cboAddress_SelectedIndexChanged(object sender, EventArgs e)
        {
            //URLNavigate(cboAddress.Text);
        }
        private void wbMyWeb_CanGoBackChanged(object s, EventArgs e)
        {
            btnBackward.Enabled = wbMyWeb.CanGoBack;
        }
        private void wbMyWeb_CanGoForwardChanged(object s, EventArgs e)
        {
            btnForward.Enabled = wbMyWeb.CanGoForward;
        }

        private void btnBackward_Click(object sender, EventArgs e)
        {
            wbMyWeb.GoBack();
        }

        private void btnForward_Click(object sender, EventArgs e)
        {
            wbMyWeb.GoForward();
        }
        private void wbMyWeb_DocumentTitleChanged(object sender, EventArgs e)
        {
            this.Text = wbMyWeb.DocumentTitle;
        }
        private void wbMyWeb_StatusTextChanged(object sender, EventArgs e)
        {
            lblStatus.Text = wbMyWeb.StatusText;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            wbMyWeb.Stop();
        }

        private void btnRefresh1_Click(object sender, EventArgs e)
        {
            wbMyWeb.Refresh();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            wbMyWeb.GoSearch();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            새창ToolStripMenuItem.PerformClick();
        }

        private void 새창ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frmNewForm = new frmMyWeb();
            frmNewForm.Show();
        }

        private void 열기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "웹문서 열기";
            openFileDialog1.Filter = "웹페이지(*.htm;*.html|웹보관파일(*.mht)|*.mht|텍스트파일(*.txt)|*.txt|모든 파일(*.*)|*.*";
            if (openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                string address = "file://" + openFileDialog1.FileName;
                wbMyWeb.Navigate(new Uri (address));
            }
        }

        private void 다른이름으로저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            wbMyWeb.ShowSaveAsDialog();
        }

        private void 페이지설정ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            wbMyWeb.ShowPageSetupDialog();
        }

        private void 인쇄ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            wbMyWeb.ShowPrintDialog();
        }

        private void 인쇄미리보기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            wbMyWeb.ShowPrintPreviewDialog();
        }

        private void 속성ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            wbMyWeb.ShowPropertiesDialog();
        }

        private void 종료XToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            열기ToolStripMenuItem.PerformClick();
        }

        private void frmMyWeb_Resize(object sender, EventArgs e)
        {
   
        }

        private void btnPageSetup_Click(object sender, EventArgs e)
        {
            페이지설정ToolStripMenuItem.PerformClick();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            인쇄미리보기ToolStripMenuItem.PerformClick();
        }

        private void btnPrintFreeview_Click(object sender, EventArgs e)
        {
            인쇄미리보기ToolStripMenuItem.PerformClick();
        }
    }
}
