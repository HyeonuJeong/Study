from abc import *
from Menu import *

class Gamer(ABC):
    __metaclass__ = ABCMeta
    Winner = "없음"
    PlayList = ['가위','바위','보']
    isGameOver=False
    def __init__(self, name):
        self.__name = name
        self. __playResult=' '
    @property
    def Name(self):
        return self.__name
    @property
    def playResult(self):
        return self.__playResult
    @playResult.setter
    def playResult(self,value):
        self.__playResult = value

    @abstractmethod 
    def play(self):
        pass

    def getWinner(self, otherPlayer): 
        if self.playResult == '가위': 
            if otherPlayer.playResult == '가위':
                Gamer.Winner='없음'
            elif otherPlayer.playResult == '바위':
                Gamer.Winner=otherPlayer.Name
            elif otherPlayer.playResult == '보':
                Gamer.Winner=self.Name
        if self.playResult == '바위':
            if otherPlayer.playResult == '가위':
                Gamer.Winner=self.Name
            elif otherPlayer.playResult == '바위':
                Gamer.Winner='없음'
            elif otherPlayer.playResult == '보':
                Gamer.Winner=otherPlayer.Name
        if self.playResult == '보':
            if otherPlayer.playResult == "가위" :
                Gamer.Winner=otherPlayer.Name
            elif otherPlayer.playResult == "바위":
                Gamer.Winner=self.Name
            elif otherPlayer.playResult == "보":
                Gamer.Winner='없음'
    def printGameResult(self, otherPlayer):
        self.getWinner(otherPlayer)
        print("{0}:{1}".format(self.Name, self.playResult))
        print("{0}:{1}".format(otherPlayer.Name, otherPlayer.playResult))
        if Gamer.Winner == '없음':
           print("{0}님이 {1}님과 비겼습니다.".format(self.Name,otherPlayer.Name))
        elif Gamer.Winner == self.Name:
           print("{0}님이 {1}님을 이겼습니다.".format(self.Name,otherPlayer.Name))
        else:
           print("{0}님이 {1}에게 졌습니다.".format(self.Name,otherPlayer.Name))

class Person(Gamer):
    def __init__(self, name="사용자"):
        super().__init__(name)
    def play(self):
        title ="가위바위보"
        myMenu=Menu(title,Gamer.PlayList)
        myMenuNumber=myMenu.printNread()
        if not myMenu.isExitNumber():
            self.playResult=Gamer.PlayList[myMenuNumber-1]
        else:
            Gamer.isGameOver = True
import random
class Computer(Gamer):
    def __init__(self, name="컴퓨터"):
        super().__init__(name)
    def play(self):
        self.playResult=random.choice(Gamer.PlayList)
                

