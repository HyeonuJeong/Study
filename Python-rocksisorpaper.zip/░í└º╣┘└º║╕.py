from RockPaperScissors import *

computerPlayer = Computer()
personPlayer=Person(input('이름을 입력하세요~:'))
personPlayer.play()
while not Gamer.isGameOver:
    computerPlayer.play()
    computerPlayer.printGameResult(personPlayer)
    print()
    input()
    personPlayer.play()
print("안녕히가세요")
input()