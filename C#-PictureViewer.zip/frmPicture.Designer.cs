﻿namespace 그림파일보기
{
    partial class frmPicture
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPicture));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnOpen = new System.Windows.Forms.Button();
            this.lblPictureName = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.lstPictureName = new System.Windows.Forms.ListBox();
            this.lstFullPictureName = new System.Windows.Forms.ListBox();
            this.btnFolderOpen = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.btnAuto = new System.Windows.Forms.Button();
            this.tmrAuto = new System.Windows.Forms.Timer(this.components);
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnMusicOpen = new System.Windows.Forms.Button();
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(454, 373);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(12, 492);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(106, 23);
            this.btnOpen.TabIndex = 1;
            this.btnOpen.Text = "그림파일열기";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // lblPictureName
            // 
            this.lblPictureName.AutoSize = true;
            this.lblPictureName.Location = new System.Drawing.Point(12, 388);
            this.lblPictureName.Name = "lblPictureName";
            this.lblPictureName.Size = new System.Drawing.Size(38, 12);
            this.lblPictureName.TabIndex = 2;
            this.lblPictureName.Text = "label1";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // lstPictureName
            // 
            this.lstPictureName.FormattingEnabled = true;
            this.lstPictureName.ItemHeight = 12;
            this.lstPictureName.Location = new System.Drawing.Point(472, 12);
            this.lstPictureName.Name = "lstPictureName";
            this.lstPictureName.Size = new System.Drawing.Size(245, 376);
            this.lstPictureName.TabIndex = 3;
            this.lstPictureName.SelectedIndexChanged += new System.EventHandler(this.lstPictureName_SelectedIndexChanged);
            // 
            // lstFullPictureName
            // 
            this.lstFullPictureName.FormattingEnabled = true;
            this.lstFullPictureName.ItemHeight = 12;
            this.lstFullPictureName.Location = new System.Drawing.Point(490, 228);
            this.lstFullPictureName.Name = "lstFullPictureName";
            this.lstFullPictureName.Size = new System.Drawing.Size(204, 148);
            this.lstFullPictureName.TabIndex = 4;
            this.lstFullPictureName.Visible = false;
            this.lstFullPictureName.SelectedIndexChanged += new System.EventHandler(this.lstFullPictureName_SelectedIndexChanged);
            // 
            // btnFolderOpen
            // 
            this.btnFolderOpen.Location = new System.Drawing.Point(124, 492);
            this.btnFolderOpen.Name = "btnFolderOpen";
            this.btnFolderOpen.Size = new System.Drawing.Size(106, 23);
            this.btnFolderOpen.TabIndex = 5;
            this.btnFolderOpen.Text = "폴더그림열기";
            this.btnFolderOpen.UseVisualStyleBackColor = true;
            this.btnFolderOpen.Click += new System.EventHandler(this.btnFolderOpen_Click);
            // 
            // btnAuto
            // 
            this.btnAuto.Location = new System.Drawing.Point(236, 492);
            this.btnAuto.Name = "btnAuto";
            this.btnAuto.Size = new System.Drawing.Size(106, 23);
            this.btnAuto.TabIndex = 6;
            this.btnAuto.Text = "자동으로보기";
            this.btnAuto.UseVisualStyleBackColor = true;
            this.btnAuto.Click += new System.EventHandler(this.btnAuto_Click);
            // 
            // tmrAuto
            // 
            this.tmrAuto.Interval = 1000;
            this.tmrAuto.Tick += new System.EventHandler(this.tmrAuto_Tick);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(348, 492);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(106, 23);
            this.btnRemove.TabIndex = 7;
            this.btnRemove.Text = "그림목록제거";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnMusicOpen
            // 
            this.btnMusicOpen.Location = new System.Drawing.Point(460, 492);
            this.btnMusicOpen.Name = "btnMusicOpen";
            this.btnMusicOpen.Size = new System.Drawing.Size(106, 23);
            this.btnMusicOpen.TabIndex = 8;
            this.btnMusicOpen.Text = "음악듣기";
            this.btnMusicOpen.UseVisualStyleBackColor = true;
            this.btnMusicOpen.Click += new System.EventHandler(this.btnMusicOpen_Click);
            // 
            // axWindowsMediaPlayer1
            // 
            this.axWindowsMediaPlayer1.Enabled = true;
            this.axWindowsMediaPlayer1.Location = new System.Drawing.Point(14, 417);
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            this.axWindowsMediaPlayer1.Size = new System.Drawing.Size(703, 45);
            this.axWindowsMediaPlayer1.TabIndex = 9;
            // 
            // frmPicture
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 527);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.Controls.Add(this.btnMusicOpen);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAuto);
            this.Controls.Add(this.btnFolderOpen);
            this.Controls.Add(this.lstFullPictureName);
            this.Controls.Add(this.lstPictureName);
            this.Controls.Add(this.lblPictureName);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.pictureBox1);
            this.Name = "frmPicture";
            this.Text = "그림파일보기";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Label lblPictureName;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ListBox lstPictureName;
        private System.Windows.Forms.ListBox lstFullPictureName;
        private System.Windows.Forms.Button btnFolderOpen;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Button btnAuto;
        private System.Windows.Forms.Timer tmrAuto;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnMusicOpen;
        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1;
    }
}

