﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace 그림파일보기
{
    public partial class frmPicture : Form
    {
        private string MyFileName;
        public frmPicture()
        {
            InitializeComponent();
        }

        private void lstPictureName_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstFullPictureName.SelectedIndex = lstPictureName.SelectedIndex;
        }

        private void lstFullPictureName_SelectedIndexChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(lstFullPictureName.SelectedItem.ToString());
            lblPictureName.Text = "파일이름 :"+lstFullPictureName.SelectedItem.ToString();

        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "그림파일 열기";
            openFileDialog1.Filter = "그림파일(*.bmp)|*.bmp|그림파일(*.jpg)|*.jpg|그림파일(*.gif)|*.gif|모든파일(*.*)|*.*";
            openFileDialog1.Multiselect = true;
            if(openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                foreach(string FullFileName in openFileDialog1.FileNames)
                {
                    int startPosition = FullFileName.LastIndexOf('\\') + 1;
                    MyFileName = FullFileName.Substring(startPosition);
                    //pictureBox1.Image = Image.FromFile(FullFileName);
                    lstFullPictureName.Items.Add(FullFileName);
                    lstPictureName.Items.Add(MyFileName);
                }
                //lstPictureName.SelectedIndex = 0;
                lstPictureName.SelectedIndex = lstPictureName.Items.Count - 1;
            }
        }

        private void btnFolderOpen_Click(object sender, EventArgs e)
        {
            string[] PictureExtension = { "*.jpg", "*.png", "*.bmp", "*.gif" };

            if(folderBrowserDialog1.ShowDialog()==DialogResult.OK)
            {
                DirectoryInfo dirInfo = new DirectoryInfo(folderBrowserDialog1.SelectedPath);
                foreach(string fileExtension in PictureExtension)
                {
                    FileInfo[] myFiles = dirInfo.GetFiles(fileExtension);
                    foreach(FileInfo myFIleinfo in myFiles)
                    {
                        lstFullPictureName.Items.Add(myFIleinfo.FullName);
                        lstPictureName.Items.Add(myFIleinfo.Name);
                    }
                }
                lstPictureName.SelectedIndex = lstPictureName.Items.Count - 1;
            }
        }

        private void btnAuto_Click(object sender, EventArgs e)
        {
            if(tmrAuto.Enabled)
            {
                tmrAuto.Stop();
                btnAuto.Text = "자동으로중지";

            }
            else
            {
                tmrAuto.Start();
                btnAuto.Text = "자동보기중지";
            }
 
            
            
        }

        private void tmrAuto_Tick(object sender, EventArgs e)
        {
            if (lstPictureName.SelectedIndex < (lstPictureName.Items.Count - 1))
            {
                lstPictureName.SelectedIndex++;
            }
            else
            {
                lstPictureName.SelectedIndex = 0;
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if(lstPictureName.Items.Count >= 1)
            {
                int saveIndex = lstPictureName.SelectedIndex;
                lstFullPictureName.Items.RemoveAt(saveIndex);
                lstPictureName.Items.RemoveAt(saveIndex);
                if(saveIndex==lstPictureName.Items.Count)
                {
                    lstPictureName.SelectedIndex = saveIndex - 1;

                }
                else
                {
                    lstPictureName.SelectedIndex = saveIndex;

                }
            }
        }

        private void btnMusicOpen_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "음악파일열기";
            openFileDialog1.Filter = "음악파일(*.mp3;*.wma)|*.mp3;*.wma|모든파일(*.*)|*.*";
            if(openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                axWindowsMediaPlayer1.URL = openFileDialog1.FileName;
            }
        }
    }
}
